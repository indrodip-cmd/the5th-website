Expertise to Income: landing page book assets
cover/      flat front cover (print/Amazon-ready 1260x1800) and web version
mockups/    3D standing book on dark, light and transparent backgrounds; cutout with shadow
pages/      8 real two-page spreads from inside the book (for "look inside" sections)
social/     link-preview image (1200x630)
authors/    author photos used on the page
email/      book image used in the emails
Live page: https://the5thglobal.consulting/book
